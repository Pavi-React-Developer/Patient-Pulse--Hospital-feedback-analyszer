import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "./api/data";
import "./Feedback.css";
function Records() {
  const [feedbacks, setFeedbacks] = useState([]);
  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] =useState("");
  const [sentimentFilter, setSentimentFilter] = useState("");
  const navigate = useNavigate();
  // FETCH FEEDBACKS
  useEffect(() => {
    const fetchFeedbacks = async () => {
      try {
        const response = await api.get( "/feedbacks");
        setFeedbacks(response.data);
      }
      catch (error) {
        console.log(error);
      }
    };
    fetchFeedbacks();
}, []);

  // DELETE FEEDBACK
  const handleDelete = async (id) => {
    try {
      await api.delete(`/feedbacks/${id}`);
      const updatedList = feedbacks.filter(
        (item) => item.id !== id
      );
      setFeedbacks(updatedList);
    }
    catch (error) {
      console.log(error);
    }
  };
  // FILTER LOGIC
  const filteredFeedbacks = feedbacks.filter(
    (item) => {
      const matchesSearch = item.name.toLowerCase() .includes(search.toLowerCase());
      const matchesDepartment = departmentFilter === "" || item.department === departmentFilter;
      const matchesSentiment = sentimentFilter === "" || item.sentiment === sentimentFilter;
      return (
        matchesSearch &&
        matchesDepartment &&
        matchesSentiment
      );
    });
  return (
    <>
      {/* NAVBAR */}
      <div className="dashboard-nav">
        <button onClick={() => navigate("/dashboard")}> Analysis</button>
        <button onClick={() => navigate("/records")}> Records</button>
      </div>
      <div className="feedback-page">
        <div className="feedback-card" style={{ maxWidth: "1200px" }} >
          <h2 className="feedback-title"> Patient Feedback Records</h2>
          <p className="feedback-subtitle"> View and manage all patient reviews</p>
          {/* FILTER SECTION */}
          <div className="filters-container">
            {/* SEARCH */}
            <input type="text" placeholder="Search Patient..." className="search-input" value={search} onChange={(e) => setSearch(e.target.value)}/>
            {/* DEPARTMENT FILTER */}
            <select className="filter-select" value={departmentFilter} onChange={(e) => setDepartmentFilter(e.target.value )}>
              <option value=""> All Departments</option>
              <option value="Cardiology"> Cardiology</option>
              <option value="Neurology"> Neurology</option>
              <option value="Emergency"> Emergency</option>
              <option value="ICU">ICU</option>
              <option value="Pediatrics"> Pediatrics</option>
              <option value="General">General</option>
            </select>
            {/* SENTIMENT FILTER */}
            <select className="filter-select" value={sentimentFilter} onChange={(e) => setSentimentFilter( e.target.value)}>
              <option value=""> All Sentiments</option>
              <option value="Positive"> Positive</option>
              <option value="Negative"> Negative</option>
              <option value="Neutral"> Neutral</option>
            </select>
          </div>
          {/* RECORDS */}
          <div className="feedback-list">
            {
              filteredFeedbacks.length === 0 ? (
                <p style={{ color: "white", textAlign: "center" }}> No Feedback Found </p>
              ) : (
                filteredFeedbacks.map((item) => (
                  <div key={item.id} className="feedback-item">
                    {/* NAME */}
                    <h4> {item.name}</h4>
                    {/* MESSAGE */}
                    <p> {item.message}</p>
                    {/* DEPARTMENT */}
                    <p><strong> Department:</strong> {" "} {item.department}</p>
                    {/* SENTIMENT */}
                    <p> <strong> Sentiment: </strong>{" "}<span style={{ color: item.sentiment === "Positive" ? "#4ade80"
                              : item.sentiment === "Negative" ? "#ef4444" : "#facc15" }}>
                        {item.sentiment}</span>
                    </p>
                    {/* PRIORITY */}
                    <p><strong>Priority:</strong>{" "}{item.priority}</p>
                    {/* DATE */}
                    <p><strong> Date:</strong>{" "} {item.date} </p>
                    {/* DELETE BUTTON */}
                    <button className="delete-btn" onClick={() => handleDelete(item.id) }> Delete </button>
                  </div>
                ))
              )}
          </div>
        </div>
      </div>
    </>
  );
}
export default Records;