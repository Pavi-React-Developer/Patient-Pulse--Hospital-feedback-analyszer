import { Navigate } from "react-router-dom";
function ProtectedRoute({ children, role }) {
  const userRole = sessionStorage.getItem("userRole");
  // login illa
  if (!userRole) {
    return <Navigate to="/" />;
  }
  // wrong role
  if (role && userRole !== role) {
    return <Navigate to="/" />;
  }
  return children;
}
export default ProtectedRoute;