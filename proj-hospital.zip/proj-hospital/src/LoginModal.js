import { useState } from "react";
import "./LoginModal.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function LoginModal({ show, handleClose }) {
  const [patientId, setPatientId] =useState("");
  const [phone, setPhone] =useState("");
  const [error, setError] =useState("");
  const [loading, setLoading] =useState(false);
  const navigate = useNavigate();

  // LOGIN FUNCTION
  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    // VALIDATION
    if (!patientId || !phone) {
      setError( "Please fill all fields");
      return;
    }
    try {
      setLoading(true);
      const res = await axios.get(
        "http://localhost:5000/patients"
      );
      const users = res.data;
      const matchedUser = users.find(
        (user) =>
          user.patientId === patientId &&
          user.phone === phone
      );
      // INVALID USER
      if (!matchedUser) {
        setError( "Invalid ID or Phone");
        setLoading(false);
        return;
      }
      // SAVE SESSION
      sessionStorage.setItem("userRole",matchedUser.role);
      sessionStorage.setItem("patientName",matchedUser.name);
      sessionStorage.setItem("patientId",matchedUser.patientId);
      // CLEAR FORM
      setPatientId("");
      setPhone("");
      // CLOSE MODAL
      handleClose();
      // NAVIGATION
      if (matchedUser.role === "admin") {
        navigate("/dashboard");
      }
      else {
        navigate("/feedback");
      }
    }
    catch (error) {
      console.log(error);
      setError("Server Error");
    }
    finally {
      setLoading(false);
    }
  };
  // CLOSE MODAL
  const closeModal = () => {
    setError("");
    setPatientId("");
    setPhone("");
    handleClose();
  };
  if (!show) return null;
  return (
    <div className="modal-overlay">
      <div className="login-modal">
        {/* CLOSE BUTTON */}
        <button className="close-btn"  onClick={closeModal}> ✕</button>
        {/* TITLE */}
        <h2 className="modal-title">Welcome Back</h2>
        <p className="modal-subtitle">
          Login to access your
          healthcare feedback portal
        </p>
        {/* FORM */}
        <form onSubmit={handleLogin}>
          {/* PATIENT ID */}
          <input
            type="text"
            placeholder="Enter ID"
            className="modal-input"
            value={patientId}
            onChange={(e) =>
              setPatientId(e.target.value)
            }/>

          {/* PHONE */}
          <input
            type="text"
            placeholder="Enter Phone Number"
            className="modal-input"
            value={phone}
            onChange={(e) =>
              setPhone(e.target.value)
            }/>

          {/* ERROR */}
          {
            error && (
              <p className="error-text">{error}</p>
            )
          }
          {/* BUTTON */}
          <button className="modal-login-btn" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default LoginModal;