import "./Navbar.css";
import {Link, NavLink, useNavigate} from "react-router-dom";

function Navbar({ openLogin }) {
  const navigate = useNavigate();
  // SESSION DATA
  const userRole =sessionStorage.getItem("userRole");
  const patientName =sessionStorage.getItem("patientName");
  // LOGOUT
  const handleLogout = () => {
    sessionStorage.removeItem("userRole");
    sessionStorage.removeItem("patientName");
    sessionStorage.removeItem( "patientId");
    navigate("/");
    window.location.reload();
  };
  return (
    <nav className="navbar navbar-expand-lg custom-navbar">
      <div className="container">
        {/* BRAND */}
        <Link className="navbar-brand brand-logo" to="/"> PatientPulse</Link>
        {/* MOBILE TOGGLE */}
        <button className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
        >
        <span className="navbar-toggler-icon">X</span>
        </button>
        {/* NAVBAR CONTENT */}
        <div className="collapse navbar-collapse"  id="navbarContent">
          {/* NAV LINKS */}
          <ul className="navbar-nav mx-auto">
            {/* HOME */}
            <li className="nav-item"> <NavLink className="nav-link nav-text" to="/"> Home</NavLink></li>
            {/* ABOUT */}
            <li className="nav-item"> <NavLink className="nav-link nav-text" to="/about"> About </NavLink></li>
            {/* CONTACT */}
            <li className="nav-item"><NavLink className="nav-link nav-text" to="/contact"> Contact </NavLink> </li>
            {/* PATIENT FEEDBACK */}
            {
              userRole === "patient" && (
                <li className="nav-item"><NavLink className="nav-link nav-text" to="/feedback"> Feedback</NavLink></li>
              )
            }
            {/* ADMIN DASHBOARD */}
            {
              userRole === "admin" && (
                <li className="nav-item"><NavLink className="nav-link nav-text" to="/dashboard"> Dashboard</NavLink></li>)
            }
          </ul>
          {/* RIGHT SIDE */}
          <div className="d-flex align-items-center gap-3">
            {/* PATIENT NAME */}
            {
              patientName && (
                <span className="patient-name"> Hi, {patientName}</span>
              )
            }
            {/* LOGIN / LOGOUT */}
            {
              userRole ? (<button className="login-btn" onClick={handleLogout}> Logout</button>
              ) : ( <button className="login-btn" onClick={openLogin} >Feedback</button>)
            }
          </div>
        </div>
      </div>
    </nav>
  );
}
export default Navbar;