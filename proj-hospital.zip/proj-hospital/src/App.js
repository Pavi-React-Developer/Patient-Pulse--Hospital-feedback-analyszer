import { useState } from "react";
import {BrowserRouter, Routes, Route} from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import Navbar from "./Navbar";
import LoginModal from "./LoginModal";
import Feedback from "./Feedback";
import Dashboard from "./Dashboard";
import Records from "./Records";
import Hero from "./Hero";
import About from "./About";
import Contact from "./Contact";
function App() {
  // LOGIN MODAL
  const [showModal, setShowModal] = useState(false);
  // FEEDBACK DATA
  const [feedbacks, setFeedbacks] =useState([]);
  // EDIT DATA
  const [editData, setEditData] =useState(null);
  // ADD FEEDBACK
  const addFeedback = (data) => {
    setFeedbacks([...feedbacks,data]);
  };
   const openLoginModal = () => {
    setShowModal(true);
  };
  // DELETE FEEDBACK
  const deleteFeedback = (id) => {
    const updatedData =feedbacks.filter((item) => item.id !== id);
    setFeedbacks(updatedData);
  };
  // UPDATE FEEDBACK
  // const updateFeedback = (updatedItem) => {
  //   const updatedList =feedbacks.map((item) =>
  //       item.id === updatedItem.id ? updatedItem: item
  //     );
  //   setFeedbacks(updatedList);
  //   // CLEAR EDIT STATE
  //   setEditData(null);
  // };
  return (

    <BrowserRouter>
      {/* NAVBAR */}
      <Navbar
        openLogin={() =>
          setShowModal(true)
        }
      />

      {/* LOGIN MODAL */}
      <LoginModal
        show={showModal}
        handleClose={() =>
          setShowModal(false)
        }
      />
      {/* ROUTES */}

      <Routes>

        {/* HOME */}
        <Route path="/" element={<Hero  openLoginModal={openLoginModal}  />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        {/* FEEDBACK PAGE */}
        <Route path="/feedback" element={
            <ProtectedRoute role="patient">
              <Feedback addFeedback={ addFeedback}
                editData={editData}
              />
            </ProtectedRoute>
          }
        />
        {/* DASHBOARD PAGE */}
        <Route path="/dashboard" element={
            <ProtectedRoute role="admin">
              <Dashboard feedbacks={feedbacks}/>
            </ProtectedRoute>
          }
        />
        {/* RECORDS PAGE */}
        <Route path="/records" element={
            <ProtectedRoute role="admin">
              <Records
                feedbacks={feedbacks}
                deleteFeedback={ deleteFeedback}
                setEditData={ setEditData}
              />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;