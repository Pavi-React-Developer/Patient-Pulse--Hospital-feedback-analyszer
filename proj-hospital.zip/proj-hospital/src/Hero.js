import "./Hero.css";

function Hero({ openLoginModal }) {
  return (
    <section className="hero-section">
      <div className="container">
        <div className="row align-items-center min-vh-100">
          {/* Left Content */}
          <div className="col-lg-6 hero-left">
            <div className="hero-badge">
              ⚡ AI-Powered Healthcare Analytics
            </div>
            <h1 className="hero-title">
              Transform Patient Feedback Into
              <span> Smarter Healthcare Decisions</span>
            </h1>
            <p className="hero-desc">
              Analyze patient feedback in real-time using AI-driven sentiment analysis,
              detect issues faster, and improve hospital experience with actionable insights.
            </p>
            <div className="hero-stats">
              <div className="stat-box">
                <h3>92%</h3>
                <p>Patient Satisfaction</p>
              </div>
              <div className="stat-box">
                <h3>1.2s</h3>
                <p>Avg Analysis Time</p>
              </div>
              <div className="stat-box">
                <h3>24/7</h3>
                <p>Monitoring</p>
              </div>
            </div>
            <div className="hero-buttons">
              <button className="primary-btn" onClick={openLoginModal}>🚀 Get Started</button>
              <button className="secondary-btn"> ▶ Watch Demo</button>
            </div>
          </div>
          {/* Right Content */}
          <div className="col-lg-6 text-center">
            <div className="hero-card">
              <div className="card-header">
                <h3>Live Feedback Insights</h3>
                <span className="live-dot"></span>
              </div>
              <div className="progress mt-4">
                <div className="progress-bar" style={{ width: "88%" }}>
                  88% Positive Sentiment
                </div>
              </div>
              <div className="feedback-box positive">
                👍 “Excellent doctor support and fast service.”
              </div>
              <div className="feedback-box positive">
                👍 “Clean environment and friendly staff.”
              </div>
              <div className="feedback-box negative">
                ⚠ “Waiting time is slightly high.”
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
export default Hero;