// About.js

import "./About.css";

function About() {
  return (
    <div className="about-container">
      <div className="about-hero">
        <h1>About Our Hospital</h1>
        <p> Providing trusted healthcare services with compassion, advanced treatment, and patient-centered care.</p>
      </div>
      <div className="about-content">
        <div className="about-card">
          <h2>Who We Are</h2>
          <p>We are committed to delivering quality healthcare services with experienced doctors, modern facilities, and a caring environment for every patient.
          </p>
        </div>
        <div className="about-card">
          <h2>Our Mission</h2>
          <p>To improve patient health through innovative medical care, technology-driven solutions, and compassionate support.
          </p>
        </div>
        <div className="about-card">
          <h2>Why Choose Us?</h2>
          <ul>
            <li>24/7 Emergency Care</li>
            <li>Experienced Specialists</li>
            <li>Modern Medical Equipment</li>
            <li>Friendly Patient Support</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default About;