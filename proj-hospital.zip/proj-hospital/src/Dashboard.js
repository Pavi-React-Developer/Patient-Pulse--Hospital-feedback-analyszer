import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid} from "recharts";
import api from "./api/data";
import "./Feedback.css";
function Dashboard() {

  const [feedbacks, setFeedbacks] = useState([]);
  const [summary, setSummary] = useState("");
  const navigate = useNavigate();
  // FETCH FEEDBACKS
  useEffect(() => {
    const fetchFeedbacks = async () => {
      try {
        const response = await api.get( "/feedbacks" );
        setFeedbacks(response.data);
      }
      catch (error) {
        console.log(error);
      }
    };
    fetchFeedbacks();
  }, []);

  // SENTIMENT COUNTS
  const positiveCount = feedbacks.filter((item) => item.sentiment === "Positive").length;
  const negativeCount = feedbacks.filter( (item) => item.sentiment === "Negative").length;
  const neutralCount = feedbacks.filter( (item) => item.sentiment === "Neutral").length;
  // PIE CHART DATA
  const sentimentData = [{name: "Positive", value: positiveCount },
    { name: "Negative", value: negativeCount},
    { name: "Neutral", value: neutralCount}  ];
  // COLORS
  const COLORS = [ "#4ade80", "#ef4444", "#facc15" ];
  // DEPARTMENT DATA
  const departmentMap = {};
  feedbacks.forEach((item) => {
    const dept = item.department || "General";
    if (departmentMap[dept]) {
      departmentMap[dept]++;
    }
    else {
      departmentMap[dept] = 1;
    }
  });
  const departmentData = Object.keys( departmentMap).map((dept) => ({
    department: dept,
    count: departmentMap[dept]
  }));
  // AI SUMMARY
  const generateSummary = () => {
    if (feedbacks.length === 0) {
      setSummary( "No feedback data available.");
      return;
    }
    // COUNTS
    const positiveFeedbacks = feedbacks.filter( (item) => item.sentiment === "Positive" );
    const negativeFeedbacks = feedbacks.filter( (item) => item.sentiment === "Negative");
    const highPriority = feedbacks.filter( (item) => item.priority === "High" );
    // MOST ACTIVE DEPARTMENT
    let topDepartment = "";
    let maxCount = 0;
    for (let dept in departmentMap) {
      if ( departmentMap[dept] > maxCount ) {
        maxCount = departmentMap[dept];
        topDepartment = dept;
      }
    }
    // ISSUE ANALYSIS
    let delayIssues = 0;
    let rudeIssues = 0;
    feedbacks.forEach((item) => {
      const msg =
        item.message.toLowerCase();
      if ( msg.includes("delay") || msg.includes("late")) {
        delayIssues++;
      }
      if ( msg.includes("rude") ) {
        rudeIssues++;
      }
    });
    // FINAL SUMMARY
    let summaryText = `The hospital feedback system analyzed ${feedbacks.length} patient reviews.
                      Most feedbacks were submitted from the ${topDepartment} department.`;
    if (positiveFeedbacks.length >negativeFeedbacks.length) {
      summaryText += `

Overall patient satisfaction appears positive.

`;}
    else {
      summaryText += `

Patient satisfaction requires improvement.

`;}
    if (highPriority.length > 0) {
      summaryText += `

${highPriority.length} high priority complaints require immediate attention.

`; }
    if (delayIssues > 0) {
      summaryText += `

Several patients reported delays in treatment.

`; }
    if (rudeIssues > 0) {
      summaryText += `

Some reviews mentioned staff behaviour concerns.

`;}
    summaryText += `

AI analysis completed successfully.
`;
    setSummary(summaryText);
  };
  return (
    <>
    <div className="dashboard-nav">
      <button onClick={() => navigate("/dashboard")}>Analysis</button>
      <button onClick={() => navigate("/records")}>Records</button>
    </div>
    <div className="feedback-page">
      
      <div
        className="feedback-card"
        style={{ maxWidth: "1200px" }}
      >

        <h2 className="feedback-title">
          Admin Analytics Dashboard
        </h2>

        <p className="feedback-subtitle">
          AI Hospital Feedback Insights
        </p>

        {/* SUMMARY CARDS */}

        <div
          style={{
            display: "flex",
            gap: "20px",
            flexWrap: "wrap",
            marginBottom: "30px"
          }}
        >

          <div className="feedback-item">
            <h4>Total Feedbacks</h4>
            <p>{feedbacks.length}</p>
          </div>

          <div className="feedback-item">
            <h4>Positive</h4>
            <p>{positiveCount}</p>
          </div>

          <div className="feedback-item">
            <h4>Negative</h4>
            <p>{negativeCount}</p>
          </div>

          <div className="feedback-item">
            <h4>Neutral</h4>
            <p>{neutralCount}</p>
          </div>

        </div>

        {/* CHARTS */}

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(350px,1fr))",
            gap: "30px",
            marginBottom: "40px"
          }}
        >

          {/* PIE CHART */}

          <div className="feedback-item">

            <h4
              style={{
                color: "white",
                marginBottom: "20px"
              }}
            >
              Sentiment Analysis
            </h4>

            <ResponsiveContainer
              width="100%"
              height={300}
            >

              <PieChart>

                <Pie
                  data={sentimentData}
                  dataKey="value"
                  outerRadius={100}
                  label
                >
                  {
                    sentimentData.map(
                      (entry, index) => (
                        <Cell key={index} fill={COLORS[index]} />
                      )
                    )
                  }
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* BAR CHART */}
          <div className="feedback-item">
            <h4 style={{ color: "white", marginBottom: "20px" }} > Department Analysis</h4>
            <ResponsiveContainer width="100%" height={300} >
              <BarChart data={departmentData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="department" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#3b82f6"/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        {/* AI SUMMARY BUTTON */}
        <button className="feedback-btn" onClick={generateSummary} style={{ marginBottom: "25px" }}> Generate Summary</button>
        {/* SUMMARY BOX */}
        {
          summary && (
            <div
              className="feedback-item" style={{ position: "relative"}}>
              {/* CLOSE BUTTON */}
              <button onClick={() => setSummary("") }
                style={{ position: "absolute", top: "10px", right: "10px",
                  background: "transparent",
                  border: "none",
                  color: "white",
                  fontSize: "22px",
                  cursor: "pointer"
                }}> ×</button>
              <h4 style={{ color: "white", marginBottom: "15px"}}>AI Hospital Summary</h4>
              <p style={{ whiteSpace: "pre-line" }}> {summary} </p>
            </div>
          )}
      </div>
    </div>
</>
  );}
export default Dashboard;