import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "./api/data";
import "./Feedback.css";

function Feedback() {
  const navigate = useNavigate();
  // FORM STATE
  const [formData, setFormData] = useState({
    id: "",
    name: "",
    department: "",
    message: "",
    sentiment: "",
    priority: "",
    date: ""
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  // GET LOGGED USER
  useEffect(() => {

    const patientName = sessionStorage.getItem("patientName");

    if (!patientName) {
      navigate("/");
      return;
    }

    setFormData((prev) => ({
      ...prev,
      name: patientName
    }));
  }, [navigate]);

  // INPUT CHANGE
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });

  };

  // SIMPLE AI ANALYSIS
  const analyzeFeedback = (message) => {
    const text = message.toLowerCase();
    const positiveWords = [
      "good", "excellent", "friendly", "clean",
      "happy", "great", "caring", "quick"
    ];

    const negativeWords = [
      "bad", "delay", "late", "terrible",
      "poor", "rude", "worst", "dirty"
    ];

    const highPriorityWords = [
      "emergency", "critical", "serious",
      "pain", "danger", "delay","not"
    ];
    let sentiment = "Neutral";
    let priority = "Medium";
    if (positiveWords.some(word => text.includes(word))) {
      sentiment = "Positive";
    }
    if (negativeWords.some(word => text.includes(word))) {
      sentiment = "Negative";
    }
    if (highPriorityWords.some(word => text.includes(word))) {
      priority = "High";
    }
    return { sentiment, priority };
  };

  // SUBMIT
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const result = analyzeFeedback(formData.message);
      const feedbackData = {
        ...formData,
        sentiment: result.sentiment,
        priority: result.priority,
        date: new Date().toLocaleString()
      };
      await api.post("/feedbacks", feedbackData);
      setSubmitted(true);
    }
    catch (error) {
      console.log(error);
    }
    finally {
      setLoading(false);
    }
  };

  // EXIT (AUTO LOGOUT)
  const handleExit = () => {
    sessionStorage.clear();
    navigate("/");
    window.location.reload();
  };

  return (
    <div className="feedback-page">
      <div className="feedback-card">
        <h2 className="feedback-title"> Patient Feedback</h2>
        <p className="feedback-subtitle">Share your hospital experience</p>
        {/* SUCCESS SCREEN */}
        {
          submitted ? (
            <div style={{ textAlign: "center" }}>
              <h3 className="success-text">Feedback Submitted Successfully ✅</h3>
              <p> Thank you for your feedback</p>
              <button className="delete-btn" onClick={handleExit}> Logout & Exit</button>
            </div>
          ) : (
            // FORM
            <form onSubmit={handleSubmit}>
              {/* NAME */}
              <input
                type="text"
                name="name"
                value={formData.name}
                className="feedback-input"
                readOnly
              />

              {/* DEPARTMENT */}
              <select
                name="department"
                value={formData.department}
                onChange={handleChange}
                className="feedback-input"
                required
              >
                <option value="">Select Department</option>
                <option value="Cardiology">Cardiology</option>
                <option value="Neurology">Neurology</option>
                <option value="Emergency">Emergency</option>
                <option value="ICU">ICU</option>
                <option value="Pediatrics">Pediatrics</option>
                <option value="General">General</option>
              </select>
              {/* MESSAGE */}
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                className="feedback-textarea"
                rows="5"
                placeholder="Write your feedback..."
                required
              />
              {/* SUBMIT */}
              <button type="submit" className="feedback-btn" disabled={loading}>
                {loading ? "Submitting..." : "Submit Feedback"}
              </button>
            </form>
          )}
      </div>
    </div>
  );
}
export default Feedback;