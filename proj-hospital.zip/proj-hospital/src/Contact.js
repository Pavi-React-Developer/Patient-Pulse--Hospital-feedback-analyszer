import "./Contact.css";

function Contact() {
  return (
    <div className="contact-page">
      <div className="contact-container">
        <div className="contact-info">
          <h1>Contact Our Hospital</h1>
          <p>We are here to help you 24/7. Reach out for appointments, emergency services, medical support, or general enquiries.
          </p>
        </div>
        <div className="detailinfo">
          <div className="info-box">
            <h3>📍 Address</h3>
            <p>ABC Multi Speciality Hospital <br />
              Trichy Main Road, Kattur <br />
              Tamil Nadu - 620019
            </p>
          </div>
          <div className="info-box">
            <h3>📞 Phone</h3>
            <p>+91 98765 43210</p>
          </div>
          <div className="info-box">
            <h3>✉ Email</h3>
            <p>support@abchospital.com</p>
          </div>
          <div className="info-box">
            <h3>🕒 Working Hours</h3>
            <p>Open 24 Hours</p>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Contact;